Overview
The DR45 Drive Tracker is a Flask-based web app that helps students log and track their driving hours. Users can create an account, log driving hours, and get logs approved after verification. Parents can approve logs via an email OTP.

This README covers how the project is set up and explains the purpose of each file.

File Structure
app.py: Main file of the Flask app. It handles routes, database interactions, and user sessions.

config.py: Contains settings like database connection details and email credentials for OTP.

base.html: The common template that all pages extend. It includes the header, footer, and shared elements.

login.html: Login page for users to sign in using email and password.

register.html: Registration page for new users to create accounts with their personal and login details.

UserMain.html: The starting page, where users can either log in or register.

dashboard.html: Shows user drive logs, where they can view and manage their recorded hours.

DR45CSS.css: Custom CSS file for styling the HTML pages.

DR45script.js: JavaScript file for any front-end functionality, such as form validation or AJAX requests.

Setup and Installation

Clone the repo:
git clone https://github.com/dhurias/DeepRun45
cd DR45-Drive-Tracker

Create a virtual environment:
python -m venv venv
Activate the environment:

For Windows:
venv\Scripts\activate

For macOS/Linux:
source venv/bin/activate

Install required packages:
pip install -r requirements.txt

Configure config.py: Add your database connection details and email config for OTP in config.py.

class Config:
    DB_HOST = 'localhost'
    DB_NAME = 'your_db_name'
    DB_USER = 'your_db_user'
    DB_PASS = 'your_db_password'
    APP_EMAIL = 'your-email@gmail.com'
    APP_PWD = 'your-email-password'

Run the app:
The app will run at http://localhost:5000.

Explanation of Files
app.py: Contains the logic for routes, database operations, and session management. It also handles OTP generation and sending.

config.py: Stores sensitive config details like database credentials and email login information.

base.html: A base template used by other pages to avoid repeating code.

login.html: Page for users to log in with their credentials. If successful, they are directed to the dashboard.

register.html: Registration page where users can create accounts by entering personal information.

UserMain.html: The landing page where users can either log in or register.

dashboard.html: Shows logged driving hours and allows users to add new entries or approve unapproved logs.

DR45CSS.css: Custom styling for the web app to make it clean and user-friendly.

DR45script.js: JavaScript for front-end functions like form validation and managing AJAX requests for logging hours.

Features
User Registration: Users can sign up by entering their email, password, and parent details.

Login: Registered users can log in with their credentials.

Drive Log Entry: Users can log their driving hours, categorizing them as day or night.

OTP Verification: After logging, parents can approve the logs by entering an OTP sent to their email.

Database-Backed: All data, including user accounts and logs, is stored in a PostgreSQL database.

Approval Mechanism: Once a parent's approval is received, the log is marked as confirmed and visible in the user's records.