let timer;
let hr = 0, min = 0, sec = 0, count = 0;
let approvedPassword = "1234"; // You can change this
let isApproved = false;

function start() {
    timer = true;
    stopWatch();
}

function stop() {
    timer = false;
}

function stopWatch() {
    if (timer) {
        count++;
        if (count === 100) {
            sec++;
            count = 0;
        }
        if (sec === 60) {
            min++;
            sec = 0;
        }
        if (min === 60) {
            hr++;
            min = 0;
            sec = 0;
        }

        document.getElementById("hr").innerText = hr.toString().padStart(2, '0');
        document.getElementById("min").innerText = min.toString().padStart(2, '0');
        document.getElementById("sec").innerText = sec.toString().padStart(2, '0');
        document.getElementById("count").innerText = count.toString().padStart(2, '0');

        setTimeout(stopWatch, 10);
    }
}

function insert() {
    // Insert new row into the table
    const table = document.getElementById("Data").getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();

    // Get the current time from the stopwatch
    const time = `${hr.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}.${count.toString().padStart(2, '0')}`;
    const date = new Date().toLocaleDateString();
    const dayNight = document.getElementById("dayNightToggle").innerText;
    const approved = isApproved ? "Approved" : "Not Approved";

    // Insert the values into the table
    newRow.innerHTML = `
        <td>${time}</td>
        <td>${date}</td>
        <td>${dayNight}</td>
        <td>${approved}</td>
    `;

    // Reset approval for next entries, but not the timer
    isApproved = false;

    // Reset the timer values to 0
    hr = 0;
    min = 0;
    sec = 0;
    count = 0;

    // Update the stopwatch display
    document.getElementById("hr").innerText = hr.toString().padStart(2, '0');
    document.getElementById("min").innerText = min.toString().padStart(2, '0');
    document.getElementById("sec").innerText = sec.toString().padStart(2, '0');
    document.getElementById("count").innerText = count.toString().padStart(2, '0');
}



document.addEventListener('DOMContentLoaded', function() {
    const dayNightToggleBtn = document.getElementById("dayNightToggle");

    // Function to toggle between day and night mode
    function toggleDayNight() {
        const body = document.body;  // Grab the body to change background color
        const currentText = dayNightToggleBtn.innerText;

        if (currentText === "Night") {
            dayNightToggleBtn.innerText = "Day";  // Change button text
            body.style.background = "linear-gradient(135deg, #1f3c75, #2f4b8b)";  // Night mode background
            body.style.color = "#ffffff";  // Light text for night mode
        } else {
            dayNightToggleBtn.innerText = "Night";  // Change button text back
            body.style.background = "linear-gradient(135deg, #cce0ff, #e6f0ff)";  // Day mode background
            body.style.color = "#2a2a2a";  // Default text color
        }
    }

    // Adding event listener to the button
    dayNightToggleBtn.addEventListener('click', toggleDayNight);
});

document.getElementById('insert').addEventListener('click', function () {
    const hr = parseInt(document.getElementById("hr").textContent);
    const min = parseInt(document.getElementById("min").textContent);
    const sec = parseInt(document.getElementById("sec").textContent);

    const totalHours = (hr + min / 60 + sec / 3600).toFixed(2);
    const isDay = document.getElementById("dayNightToggle").textContent === "Night";

    document.getElementById("insertTime").value = totalHours;
    document.getElementById("insertIsDay").value = isDay;

    document.getElementById("insertForm").submit();
});

document.getElementById("btnApprove").addEventListener("click", function () {
    const OTPInput = document.getElementById("txtotp").value;

    fetch("/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_otp: OTPInput })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            fetch("/approve")
                .then(response => {
                    if (response.ok) {
                        document.querySelectorAll(".approval-status").forEach(cell => {
                            cell.innerHTML = '<span class="badge bg-success">Approved</span>';
                        });
                        alert("All pending recorded time are approved.")
                    } else {
                        alert("Approval failed. Try again.");
                    }
                });
        } else {
            alert("Incorrect OTP.");
        }
    })
    .catch(err => {
        console.error("Error verifying OTP:", err);
        alert(err.toString());
    });
});


document.getElementById("btnSendOTP").addEventListener("click", function () {

    fetch("/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "sendOTP" })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("OTP Sent.");
        } else {
            alert("Error sending OTP.");
        }
    })
    .catch(err => {
        console.error("Error verifying password:", err);
        alert("Something went wrong.");
    });
});



function approve() {
    const passwordInput = document.getElementById("password");
    const password = passwordInput.value;

    if (password === approvedPassword) {
        const table = document.getElementById("Data").getElementsByTagName('tbody')[0];
        for (let row of table.rows) {
            row.cells[3].innerText = "Approved";
        }
        isApproved = true;
        // alert("Approved all current entries.");
    } else {
        // alert("Incorrect password.");
        isApproved = false;
    }

    passwordInput.value = "";
}

function calc() {
    const table = document.getElementById("Data").getElementsByTagName('tbody')[0];
    let approvedCount = 0, notApprovedCount = 0;
    let fullDayHours = 0, fullNightHours = 0, totalHours = 0;

    // Loop through each row to calculate hours based on Day/Night
    for (let row of table.rows) {
        const status = row.cells[3].innerText;
        const dayNight = row.cells[2].innerText; // Get Day/Night value
        const timeString = row.cells[0].innerText; // Get time string (HH:MM:SS.milliseconds)
        // Split the time string into components
        const timeParts = timeString.split('.');
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);
        const seconds = 0;

        const totalRowTime = (hours * 3600) + (minutes * 60) + seconds; // Total time in seconds

        // Add to the appropriate category
        if (dayNight === "Day") {
            fullDayHours += totalRowTime;
        } else if (dayNight === "Night") {
            fullNightHours += totalRowTime;
        }

        if (status === "Approved") {
            approvedCount++;
        } else {
            notApprovedCount++;
        }

        totalHours += totalRowTime;
    }

    // Display the calculated times
    document.getElementById("fullDayHours").innerText = formatTime(fullDayHours);
    document.getElementById("fullNightHours").innerText = formatTime(fullNightHours);
    document.getElementById("totalHours").innerText = formatTime(totalHours);

    // alert(`Total entries: ${table.rows.length}\nApproved: ${approvedCount}\nNot Approved: ${notApprovedCount}`);
}

    // Convert time from seconds to hours, minutes, and seconds
    function formatTime(seconds) {
        const hrs = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }


// Attach event listeners directly after DOM loads
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('start').addEventListener('click', start);
    document.getElementById('stop').addEventListener('click', stop);
    document.getElementById('insert').addEventListener('click', insert);
    document.getElementById('dayNightToggle').addEventListener('click', toggleDayNight);
    document.querySelector('.abtn').addEventListener('click', approve);
    document.querySelector('.dbtn').addEventListener('click', calc);
});
