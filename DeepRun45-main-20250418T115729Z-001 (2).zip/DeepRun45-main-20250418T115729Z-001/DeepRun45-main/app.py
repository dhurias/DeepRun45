from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config
from datetime import datetime
import random
import smtplib
from email.mime.text import MIMEText
import time

app = Flask(__name__)
app.config.from_object(Config)

def get_db_connection():
    try:
        conn = psycopg2.connect(
            host=app.config['DB_HOST'],
            database=app.config['DB_NAME'],
            user=app.config['DB_USER'],
            password=app.config['DB_PASS'],
            cursor_factory=RealDictCursor
        )
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

@app.route('/')
def user_main():
    return render_template('UserMain.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        studentid = request.form['studentid']
        parent_phone = request.form.get('parentphonenum','')
        parent_email = request.form.get('parentemail','')
        email = request.form['emailcreate']
        password = request.form['passwordcreate']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        if cur.fetchone():
            flash("Email already registered.", "danger")
            return redirect(url_for('register'))

        cur.execute("""
            INSERT INTO users (firstname, lastname, studentid, parent_phone, email, password, parent_email)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (firstname, lastname, studentid, parent_phone, email, password, parent_email))

        table_name = email.replace('@', '_').replace('.', '_') + "_drive_log"
        cur.execute(f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                id SERIAL PRIMARY KEY,
                time NUMERIC(4, 2),
                date DATE,
                isday BOOLEAN DEFAULT TRUE,
                approved BOOLEAN DEFAULT FALSE
            )
        """)

        conn.commit()
        cur.close()
        conn.close()

        flash("Account created! Please log in.", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['emaillogin']
        password = request.form['passwordlogin']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()
        conn.close()

        if user and user['password'] == password:
            session['user_email'] = email
            session['parent_email'] = user['parent_email']
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password", "danger")

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_email' not in session:
        flash("Please log in first", "warning")
        return redirect(url_for('login'))

    email = session['user_email']
    table_name = email.replace('@', '_').replace('.', '_') + "_drive_log"

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table_name} ORDER BY date DESC, id DESC")
    entries = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('dashboard.html', user=email, logs=entries)

@app.route('/insert', methods=['POST'])
def insert():
    if 'user_email' not in session:
        flash("Please log in first", "warning")
        return redirect(url_for('login'))

    email = session['user_email']
    table_name = email.replace('@', '_').replace('.', '_') + "_drive_log"

    time_value = request.form['time']
    is_day = request.form.get('isday') == 'true'

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f"""
        INSERT INTO {table_name} (time, date, isday, approved)
        VALUES (%s, %s, %s, %s)
    """, (float(time_value), datetime.today().date(), is_day, False))
    conn.commit()
    cur.close()
    conn.close()

    flash("Time recorded successfully!", "success")
    return redirect(url_for('dashboard'))

# NEW: AJAX-friendly insert route
@app.route('/insert-entry', methods=['POST'])
def insert_entry():
    if 'user_email' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    email = session['user_email']
    table_name = email.replace('@', '_').replace('.', '_') + "_drive_log"

    try:
        data = request.get_json()
        time_value = float(data.get('time', 0))
        is_day = data.get('isday', True)

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(f"""
            INSERT INTO {table_name} (time, date, isday, approved)
            VALUES (%s, %s, %s, %s)
            RETURNING id, time, date, isday, approved
        """, (time_value, datetime.today().date(), is_day, False))
        new_entry = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()

        return jsonify({'success': True, 'entry': new_entry})
    except Exception as e:
        print("Insert error:", e)
        return jsonify({'success': False, 'message': 'Insert failed'}), 500

@app.route('/approve')
def approve():
    if 'user_email' not in session:
        flash("Please log in first", "warning")
        return redirect(url_for('login'))

    email = session['user_email']
    table_name = email.replace('@', '_').replace('.', '_') + "_drive_log"

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f"UPDATE {table_name} SET approved = TRUE WHERE approved = FALSE")
    conn.commit()
    cur.close()
    conn.close()
    flash("All unapproved entries marked approved.", "success")
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('user_main'))

@app.route('/verify-password', methods=['POST'])
def verify_password():
    if 'user_email' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    data = request.get_json()
    entered_password = data.get('password')

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT password FROM users WHERE email = %s", (session['user_email'],))
    user = cur.fetchone()
    cur.close()
    conn.close()

    if user and user['password'] == entered_password:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Incorrect password'}), 403


def send_email_otp(otp_code):
    msg = MIMEText(f"Your OTP is: {otp_code}")
    msg["Subject"] = "Your OTP Code"
    msg["From"] = app.config['APP_EMAIL']
    msg["To"] = session["parent_email"]

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        # server.starttls()
        server.login(msg["From"], app.config['APP_PWD'])
        #server.sendmail(msg["From"], msg["To"], msg.as_string())
        server.send_message(msg)

@app.route('/send-otp', methods=['POST'])
def send_otp():
    otp = str(random.randint(100000, 999999))
    session["otp"] = otp
    session["otp_time"] = time.time()
    send_email_otp(otp)
    return jsonify({'success': True})

@app.route('/verify-otp', methods=['POST'])
def verify_otp():
        data = request.get_json()
        user_otp = data.get('user_otp')
        
        if time.time() - session.get("otp_time", 0) > 300:
            return jsonify({'error': 'OTP expired. Please request a new one.'}) 
        
        if user_otp == session.get("otp"):
            return jsonify({'success': True})
        else:
            return jsonify({'success': False})


if __name__ == '__main__':
    app.run(debug=True)
