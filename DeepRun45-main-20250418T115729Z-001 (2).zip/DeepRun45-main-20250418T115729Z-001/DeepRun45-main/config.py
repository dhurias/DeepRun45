import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your_secret_key_here'
    DB_HOST = "drhscit.org"
    DB_NAME = "dr45"
    DB_USER = "dr45"
    DB_PASS = "3015"  # Consider moving this to environment variable for security
    APP_EMAIL = "deeprundriverecord@gmail.com"
    APP_PWD = "vwjaphqqotxdhksz" #"DeepRun1234$"
